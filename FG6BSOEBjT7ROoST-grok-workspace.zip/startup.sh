#!/bin/sh
set -eu
cd /workspace
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi
python3 -m http.server 8080 --bind 0.0.0.0 --directory /workspace/site >/tmp/senaoane-http.log 2>&1 &
i=0
while [ "$i" -lt 25 ]; do
  if curl -sf -o /dev/null --max-time 1 http://127.0.0.1:8080/; then
    exit 0
  fi
  i=$((i+1))
  sleep 0.2
done
exit 0
